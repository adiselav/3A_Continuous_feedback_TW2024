const { DataTypes } = require('sequelize');
const { sequelize } = require('../config/database');
const Activity = require('./Activity');

const User = sequelize.define('User', {
    id: {
        type: DataTypes.INTEGER,
        primaryKey: true,
        autoIncrement: true,
    },
    email: {
        type: DataTypes.STRING,
        allowNull: false,
        unique: true,
    },
    password: {
        type: DataTypes.STRING,
        allowNull: false,
    },
    role: {
        type: DataTypes.ENUM('professor', 'student'),
        allowNull: false,
    },
});

User.belongsToMany(Activity, { through: 'StudentActivities' });
Activity.belongsToMany(User, { through: 'StudentActivities' });

module.exports = User;
